package com.example.plantnursery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantnurseryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlantnurseryApplication.class, args);
	}

}
